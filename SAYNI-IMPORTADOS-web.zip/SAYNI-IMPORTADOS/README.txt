SAYNI IMPORTADOS — sitio web

Esta carpeta contiene la primera versión de la tienda independiente:
- 18 productos cargados.
- 10 fotos reales de Victoria's Secret proporcionadas por la clienta.
- Carrito de compras.
- Datos del cliente y dirección.
- Pago únicamente por transferencia Mercado Pago.
- CVU configurado.
- Pedido preparado para enviarse por correo a naylaeroldan@icloud.com.

IMPORTANTE:
GitHub Pages publica archivos estáticos. La versión actual usa mailto para abrir el correo del cliente al enviar el pedido. Para que el pedido llegue automáticamente por email sin abrir una app de correo, habrá que conectar un servicio de formularios/backend (por ejemplo Formspree/FormSubmit) y hacer una pequeña configuración.

PUBLICACIÓN:
1. Crear una cuenta en GitHub.
2. Crear un repositorio público.
3. Subir todo el contenido de esta carpeta manteniendo la carpeta assets.
4. Activar GitHub Pages desde Settings > Pages > Deploy from a branch > main > /(root).
5. GitHub publicará el sitio en una dirección github.io. Puede tardar unos minutos.

Las fotos que faltan de Bare Vanilla, Midnight Bloom, Velvet Petals y Karseell quedaron como espacios provisionales para reemplazarlas cuando estén disponibles.
